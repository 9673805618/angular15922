export class Login{
    userId: string ="";
    password: string ="";
    designation: string ="";
    loginId: number = 0;

}