export class SlabDetails{
    slabId : number=0;
    designation:string ="";
    slabBudget : number=0;
    modeOfTravel : string ="";
}