import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from 'src/app/domain/login';

@Component({
  selector: 'app-director-page',
  templateUrl: './director-page.component.html',
  styleUrls: ['./director-page.component.css']
})
export class DirectorPageComponent implements OnInit {
  login:Login=new Login();
  base:string="";
  constructor(private router:Router) { }

  ngOnInit(): void {
    this.login = JSON.parse(sessionStorage.getItem('login') || '{}');
    this.base="Welcome  "+ this.login.userId+"..!";
  }
  logout(){
    this.router.navigate(['login'])
  }
  viewtravelrequest(){
    this.router.navigate(['viewalltravelrequest'])
  }

}
